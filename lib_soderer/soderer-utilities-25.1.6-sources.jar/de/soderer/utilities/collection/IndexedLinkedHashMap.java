package de.soderer.utilities.collection;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class IndexedLinkedHashMap<K, V> extends LinkedHashMap<K, V> {
	private static final long serialVersionUID = -1676269301623131177L;

	private List<K> keyList = null;

	@SuppressWarnings("unlikely-arg-type")
	@Override
	public V remove(final Object key) {
		keyList = null;
		return super.remove(key);
	}

	@Override
	public V put(final K key, final V value) {
		keyList = null;
		return super.put(key, value);
	}

	@Override
	public void putAll(final Map<? extends K, ? extends V> map) {
		keyList = null;
		super.putAll(map);
	}

	public List<K> getKeyList() {
		if (keyList == null) {
			keyList = new ArrayList<>(keySet());
		}

		return keyList;
	}

	public int getIndexOfKey(final K key) {
		for (int i = 0; i < getKeyList().size(); i++) {
			if (getKeyList().get(i).equals(key)) {
				return i;
			}
		}
		return -1;
	}

	public K getKey(final int i) {
		return getKeyList().get(i);
	}

	public V getValue(final int i) {
		return get(getKey(i));
	}
}
